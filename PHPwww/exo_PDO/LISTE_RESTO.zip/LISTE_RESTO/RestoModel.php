<?php



class RestoModel
{
    public string $nom;
    public string $adresse;
    public float $prix;
    public string $commentaire;    
    public float $note;
    public string $visite;
    

    public function __construct() {}

    public function isValid(): bool
    {   // verifier chaques functions pour cibler l erreure s il y a 
        if (!empty($this->nom)) {
            return false;
        }
        return true; 
        
        if(!empty($this->adesse)) {
            return false;
        }
        return true;
        
        if (!empty($this->prix)) {
            return false;
        }
        return true;
        
        if (!empty($this->commentaire)) {
            return false;
        }
        return true;
        
        if (!empty($this->note)) {
            return false;
        }
        return true;
        
        if (!empty($this->visite)) {
            return false;
        }
        return true;

    }
    }
