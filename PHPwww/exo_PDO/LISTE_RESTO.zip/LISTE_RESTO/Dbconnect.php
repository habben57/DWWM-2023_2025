<?php

class Dbconnect
{

    private string $host;
    private string $dbName;
    private string $user;
    private string $mdp;

    public function __construct(string $_host, string $_dbname, string $_user, string $_mdp)
    {
        $this->host = $_host;
        $this->dbName = $_dbname;
        $this->user = $_user;
        $this->mdp = $_mdp;
    }

    public function tryConnect(): ?PDO
    {

        try {

            $myConnection = new PDO("mysql:host=$this->host;port=3306;dbname=$this->dbName;charset=utf8", $this->user, $this->mdp);

            return $myConnection;
        } catch (PDOException $e) {

            echo " erreur connexion :" . $e->getMessage();


            return null;
        }
    }
}
